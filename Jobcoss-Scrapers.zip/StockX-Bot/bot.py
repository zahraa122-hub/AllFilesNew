import asyncio
import pandas as pd
from patchright.async_api import async_playwright
import time
import os
import re

# Read CSV file (any .csv file in the current directory)
csv_files = [file for file in os.listdir() if file.lower().endswith('.csv') and file.lower() != 'output.csv']  # NOQA
input_file = csv_files[0] if csv_files else None

df = pd.read_csv(input_file, dtype=str, keep_default_na=False)
df = df[~df.apply(lambda row: bool(re.search(r',{5,}', ','.join(row.astype(str)))), axis=1)]
df.to_csv(input_file, index=False)

shoe_sku_size = list(zip(df['SKU'], df['Size']))
shoe_sku_size = [(sku, size) for sku, size in shoe_sku_size if not pd.isna(size)]


def read_file_data(filename):
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done_skus = read_file_data(os.path.join(os.path.dirname(__file__), "already-done.txt"))

# Ensure columns exist in output DataFrame
output_df = df.copy()
output_df['Sell Price'] = ""
output_df['Lowest Ask'] = ""
output_df['Last Sale'] = ""


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch_persistent_context(headless=False, user_data_dir='UserDir',
                                                             no_viewport=True)
        page = await browser.new_page()
        await browser.clear_cookies()

        visited_skus = {}
        processed_count = 0

        # SCRAPE STOCK X URLS
        for index, (sku, size) in enumerate(shoe_sku_size):
            if sku and size and f"{sku}-{size}" in already_done_skus:  # NOQA
                print(f"Skipping SKU: {sku} - Size: {size}")
                continue

            # Get the product description for this row
            product_name = df.loc[index, 'Description']
            size_modifiers = ""
            if "(GS)" in product_name or "(PS)" in product_name:
                size_modifiers += "Y"
            if "(TD)" in product_name:
                size_modifiers += "C"
            if "(Women's)" in product_name:
                size_modifiers += "W"

            if sku in visited_skus:
                product_link_href = visited_skus[sku] + f'?size={size}{size_modifiers}'
            else:
                url = f"https://stockx.com/search?s={sku}"

                try:
                    await page.goto(url, wait_until="load", timeout=120000)
                except:
                    print(f"Failed to load URL: {url}")
                    continue

                time.sleep(2)
                await page.wait_for_selector('//div[@data-testid="productTile"]//*[@class="stockx-icon "]')

                product_link = await page.query_selector('//a[@data-testid="productTile-ProductSwitcherLink"]')
                if product_link:
                    product_link_href = await product_link.get_attribute('href')
                    product_link_href = 'https://stockx.com/' + product_link_href
                    visited_skus[sku] = product_link_href
                    product_link_href += f'?size={size}{size_modifiers}'
                else:
                    print(f"No product found for SKU: {sku}")
                    continue

            # SCRAPE PRODUCT PAGE URL

            try:
                await page.goto(product_link_href, wait_until="load", timeout=120000)
            except:
                print(f"Failed to load URL: {product_link_href}")
                continue

            # Check if "All" size option is available
            all_size = await page.query_selector("//button//*[text()='All']")

            if all_size:
                correct_url = None  # Store the valid URL
                for modifier in ["Y", "C", "W"]:
                    temp_url = re.sub(r'\?size=.*', '', product_link_href)  # Remove any existing ?size=
                    temp_url += f"?size={size}{modifier}"
                    try:
                        await page.goto(temp_url, wait_until="load", timeout=120000)
                        time.sleep(1)

                        # Check if "All" size is still present
                        all_size_check = await page.query_selector("//button//*[text()='All']")
                        if not all_size_check:
                            correct_url = temp_url  # Store the first valid URL
                            break

                    except:
                        print(f"Failed to load URL with modifier {modifier}: {temp_url}")
                        continue

                if correct_url:
                    product_link_href = correct_url

            try:
                await page.wait_for_selector("//a[contains(text(), 'Place Ask')]", timeout=60000)
            except:
                pass

            sell_button = await page.query_selector("//button//p[contains(text(),'Sell')]") # NOQA
            if sell_button:
                await sell_button.click()
                time.sleep(1)

            # SCRAPE LOWEST ASK AND LAST SALE
            sell_now_elem = await page.query_selector("//h2[contains(text(),'$')]")
            lowest_ask_elem = await page.query_selector("//*[text()='Lowest Ask:']/..//p[2]")
            last_sale_elem = await page.query_selector("//*[text()='Last Sale:']/..//div[1]")

            sell_now_value = await sell_now_elem.inner_text() if sell_now_elem else "NA"
            lowest_ask_value = await lowest_ask_elem.inner_text() if lowest_ask_elem else "NA"
            last_sale_value = await last_sale_elem.inner_text() if last_sale_elem else "NA"

            sell_now_value = sell_now_value.replace('--', 'NA')
            lowest_ask_value = lowest_ask_value.replace('--', 'NA')
            last_sale_value = last_sale_value.replace('--', 'NA')

            print(
                f"Url: {product_link_href} | Sell Price: {sell_now_value} | Lowest Ask: {lowest_ask_value} | Last Sale: {last_sale_value}")

            # Save results in output DataFrame
            output_df.loc[index, 'Sell Price'] = sell_now_value
            output_df.loc[index, 'Lowest Ask'] = lowest_ask_value
            output_df.loc[index, 'Last Sale'] = last_sale_value
            output_df.to_csv(os.path.join(os.path.dirname(__file__), "output.csv"), index=False)

            processed_count += 1

            # Append to already-done.txt
            with open(os.path.join(os.path.dirname(__file__), "already-done.txt"), 'a', encoding='utf-8') as file:
                file.write(f"{sku}-{size}\n")

            # Clear cookies every 100 URLs
            if processed_count % 100 == 0:
                print("Clearing cookies...")
                await browser.clear_cookies()
                time.sleep(2)  # Pause to ensure cookies clear before continuing


if __name__ == "__main__":
    asyncio.run(main())
