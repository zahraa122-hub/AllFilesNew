from curl_cffi import requests
import pandas as pd
import os
import re
import time

# Read CSV file (any .csv file in the current directory)
csv_files = [file for file in os.listdir() if file.lower().endswith('.csv') and file.lower() != 'Output.csv']  # NOQA
input_file = csv_files[0] if csv_files else None
df = pd.read_csv(input_file, dtype=str, keep_default_na=False)

# Remove rows with excessive empty columns
df = df[~df.apply(lambda row: bool(re.search(r',{5,}', ','.join(row.astype(str)))), axis=1)]
df.to_csv(input_file, index=False)

SIZE_MAPPING = {
    'S': '104',
    'M': '105',
    'L': '106',
    'XL': '107',
    'XXL': '108',
    'XXXL': '109'
}


def convert_size(size):
    return SIZE_MAPPING.get(size.upper(), size)


# Function to clean SKU like add %20 into spaces
def clean_sku(sku):
    return sku.replace(" ", "%20")


# Extract and clean SKU and Size pairs
shoe_sku_size = list(zip(df['SKU'], df['Size']))
shoe_sku_size = [(clean_sku(sku), convert_size(size)) for sku, size in shoe_sku_size if not pd.isna(size)]


def read_file_data(filename):  # NOQA
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done_skus = read_file_data(os.path.join(os.path.dirname(__file__), "already-done.txt"))

headers = {
    "accept": "*/*",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "origin": "https://www.goat.com",
    "priority": "u=1, i",
    "sec-ch-ua-mobile": "?0",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
}


def format_price(price):
    if isinstance(price, int):
        return f"${price // 100}"
    elif isinstance(price, str) and price.isdigit():
        return f"${int(price) // 100}"
    return "NA"


for index, (sku, size) in enumerate(shoe_sku_size):
    if sku and size and f"{sku}-{size}" in already_done_skus:  # NOQA
        print(f"Skipping SKU: {sku} - Size: {size}")
        continue

    # STEP 1: GET PRODUCT ID FOR SKU
    sku_url = f"https://ac.cnstrc.com/search/{sku}"
    id_querystring = {
        "c": "ciojs-client-2.54.0", "key": "key_XT7bjdbvjgECO5d8",
        "i": "9f07288d-6764-4b9b-aeff-dab4740eb0f8",
        "s": "5", "page": "1", "num_results_per_page": "24",
        "sort_by": "relevance", "sort_order": "descending",
        "_dt": str(int(time.time() * 1000))
    }

    response = requests.get(sku_url, headers=headers, params=id_querystring)
    product_data = response.json()  # NOQA

    if not product_data['response']['results']:
        print(f"SKU: {sku} not found")
        continue

    product_id = product_data['response']['results'][0]['data']['id']
    product_slug = product_data['response']['results'][0]['data']['slug']

    # STEP 2: GET SELL PRICE, LOWEST ASK
    price_url = "https://www.goat.com/web-api/v1/product_variants/buy_bar_data"
    querystring = {"productTemplateId": product_id, "countryCode": "US"}

    while True:
        response = requests.get(price_url, headers=headers, params=querystring)
        if response.status_code == 200:
            break
        time.sleep(5)

    json_data = response.json()

    sell_price = "NA"
    lowest_price = "NA"
    last_sale = "NA"

    for variant in json_data:
        variant_size = variant.get("sizeOption", {}).get("value", "NA")
        if str(variant_size) != str(size):
            continue

        sell_price = variant.get("instantShipLowestPriceCents", {}).get("amount", "NA")
        lowest_price = variant.get("lowestPriceCents", {}).get("amount", "NA")
        last_sale = variant.get("lastSoldPriceCents", {}).get("amount", "NA")

        sell_price = format_price(sell_price)
        lowest_price = format_price(lowest_price)
        last_sale = format_price(last_sale)
        break

    # STEP 3: GET TOP SALE PRICE
    top_price_url = "https://www.goat.com/web-api/v1/highest_offers"
    top_querystring = {"productTemplateId": product_id, "countryCode": "US"}

    while True:
        response = requests.get(top_price_url, headers=headers, params=top_querystring)
        if response.status_code == 200:
            break
        time.sleep(5)

    json_data = response.json()
    top_sale = "NA"
    for offer in json_data:
        # Check if the offer size matches our target size
        offer_size = str(offer.get('size', 'NA'))
        if offer_size == str(size):
            amount = offer['offerAmountCents']['amount']
            top_sale = format_price(amount)
            break

    print(
        f"SKU: {sku} | Size: {size} | Sell: {sell_price} | Lowest: {lowest_price} | Last Sale: {last_sale} | Top Sale: {top_sale}")
