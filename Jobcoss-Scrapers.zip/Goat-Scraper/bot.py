from curl_cffi import requests
import pandas as pd
import os
import re
import time

# Read CSV file (any .csv file in the current directory)
csv_files = [file for file in os.listdir() if file.lower().endswith('.csv') and file.lower() != 'Output.csv']  # NOQA
input_file = csv_files[0] if csv_files else None
df = pd.read_csv(input_file, dtype=str, keep_default_na=False)

# Remove rows with excessive empty columns
df = df[~df.apply(lambda row: bool(re.search(r',{5,}', ','.join(row.astype(str)))), axis=1)]
df.to_csv(input_file, index=False)

SIZE_MAPPING = {
    'S': '104',
    'M': '105',
    'L': '106',
    'XL': '107',
    'XXL': '108',
    'XXXL': '109'
}


def convert_size(size):
    return SIZE_MAPPING.get(size.upper(), size)


# Function to clean SKU like add %20 into spaces
def clean_sku(sku):
    return sku.replace(" ", "%20")


# Extract and clean SKU and Size pairs
shoe_sku_size = list(zip(df['SKU'], df['Size']))
shoe_sku_size = [(clean_sku(sku), convert_size(size)) for sku, size in shoe_sku_size if not pd.isna(size)]


def read_file_data(filename):  # NOQA
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done_skus = read_file_data(os.path.join(os.path.dirname(__file__), "already-done.txt"))

# Ensure columns exist in output DataFrame
output_df = df.copy()
output_df['Sell Price'] = ""
output_df['Lowest Ask'] = ""
output_df['Last Sale'] = ""
output_df['Top Sale'] = ""

# Check if Output.csv exists and load previous data if it does
output_file_path = os.path.join(os.path.dirname(__file__), "Output.csv")
previous_output = None
if os.path.exists(output_file_path):
    try:
        previous_output = pd.read_csv(output_file_path, dtype=str, keep_default_na=False)
    except Exception as e:
        print(f"Error reading previous output file: {e}")

headers = {
    "accept": "*/*",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "origin": "https://www.goat.com",
    "priority": "u=1, i",
    "sec-ch-ua-mobile": "?0",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
}


def format_price(price):
    if isinstance(price, int):
        return f"${price // 100}"
    elif isinstance(price, str) and price.isdigit():
        return f"${int(price) // 100}"
    return "NA"


# 1K80%20110%20001
# 1K80%20110%200001
# 1K80 110 001


for index, (sku, size) in enumerate(shoe_sku_size):
    current_row_index = df[(df['SKU'] == sku.replace("%20", " ")) & (df['Size'] == size)].index.tolist()

    if not current_row_index:
        print(f"Could not find row for SKU: {sku} - Size: {size}")
        continue

    current_row_index = current_row_index[0]

    if sku and size and f"{sku}-{size}" in already_done_skus:  # NOQA
        print(f"Found already processed: SKU: {sku} - Size: {size}, getting data from previous output")

        # If we have a previous output file, try to get the values from there
        if previous_output is not None:
            # Find matching row in previous output
            prev_row = previous_output[(previous_output['SKU'] == sku.replace("%20", " ")) &
                                       (previous_output['Size'] == size)]

            if not prev_row.empty:
                sell_price = prev_row['Sell Price'].values[0]
                lowest_price = prev_row['Lowest Ask'].values[0]
                last_sale = prev_row['Last Sale'].values[0]
                top_sale = prev_row['Top Sale'].values[0]

                # Update current output dataframe with values from previous output
                output_df.loc[current_row_index, 'Sell Price'] = sell_price
                output_df.loc[current_row_index, 'Lowest Ask'] = lowest_price
                output_df.loc[current_row_index, 'Last Sale'] = last_sale
                output_df.loc[current_row_index, 'Top Sale'] = top_sale

                print(
                    f"Retrieved from previous output: SKU: {sku} | Size: {size} | Sell: {sell_price} | Lowest: {lowest_price} | Last Sale: {last_sale}")
                continue
            else:
                print(f"Could not find data in previous output for SKU: {sku} - Size: {size}, scraping again")
        else:
            print(f"No previous output file found for SKU: {sku} - Size: {size}, scraping again")

    # STEP 1: GET PRODUCT ID FOR SKU
    sku_url = f"https://ac.cnstrc.com/search/{sku}"
    print(sku_url)

    id_querystring = {
        "c": "ciojs-client-2.54.0", "key": "key_XT7bjdbvjgECO5d8",
        "i": "9f07288d-6764-4b9b-aeff-dab4740eb0f8",
        "s": "5", "page": "1", "num_results_per_page": "24",
        "sort_by": "relevance", "sort_order": "descending",
        "_dt": str(int(time.time() * 1000))
    }

    response = requests.get(sku_url, headers=headers, params=id_querystring)
    product_data = response.json()  # NOQA

    if not product_data['response']['results']:
        print(f"SKU: {sku} not found")
        continue

    product_id = product_data['response']['results'][0]['data']['id']
    product_slug = product_data['response']['results'][0]['data']['slug']

    # STEP 2: GET SELL PRICE, LOWEST ASK
    price_url = "https://www.goat.com/web-api/v1/product_variants/buy_bar_data"
    querystring = {"productTemplateId": product_id, "countryCode": "US"}

    while True:
        response = requests.get(price_url, headers=headers, params=querystring)
        if response.status_code == 200:
            break
        print(f"Retrying in 5 seconds for SKU: {sku} - Size: {size}")
        time.sleep(5)

    json_data = response.json()

    sell_price = "NA"
    lowest_price = "NA"
    last_sale = "NA"

    for variant in json_data:
        variant_size = variant.get("sizeOption", {}).get("value", "NA")
        if str(variant_size) != str(size):
            continue

        sell_price = variant.get("instantShipLowestPriceCents", {}).get("amount", "NA")
        lowest_price = variant.get("lowestPriceCents", {}).get("amount", "NA")
        last_sale = variant.get("lastSoldPriceCents", {}).get("amount", "NA")

        sell_price = format_price(sell_price)
        lowest_price = format_price(lowest_price)
        last_sale = format_price(last_sale)
        break

    # STEP 3: GET TOP SALE PRICE
    top_price_url = "https://www.goat.com/web-api/v1/highest_offers"
    top_querystring = {"productTemplateId": product_id, "countryCode": "US"}
    response = requests.get(top_price_url, headers=headers, params=top_querystring)

    top_sale = "NA"  # Define default value outside the if block
    if response.status_code == 200:
        top_sale_data = response.json()
        for offer in top_sale_data:
            # Check if the offer size matches our target size
            offer_size = str(offer.get('size', 'NA'))
            if offer_size == str(size):
                amount = offer['offerAmountCents']['amount']
                top_sale = format_price(amount)
                break

    print(
        f"SKU: {sku} | Size: {size} | Sell: {sell_price} | Lowest: {lowest_price} | Last Sale: {last_sale} | Top Sale: {top_sale}")

    # SAVE RESULTS IN OUTPUT DATAFRAME
    output_df.loc[current_row_index, 'Sell Price'] = sell_price
    output_df.loc[current_row_index, 'Lowest Ask'] = lowest_price
    output_df.loc[current_row_index, 'Last Sale'] = last_sale
    output_df.loc[current_row_index, 'Top Sale'] = top_sale
    output_df.to_csv(output_file_path, index=False)

    # APPEND SKU-Size to already-done.txt if it's not already there
    if f"{sku}-{size}" not in already_done_skus:
        with open(os.path.join(os.path.dirname(__file__), "already-done.txt"), 'a', encoding='utf-8') as file:
            file.write(f"{sku}-{size}\n")
        # Add to our in-memory list too
        already_done_skus.append(f"{sku}-{size}")
