import requests
import csv
import os

output_file = 'Output.csv'
# Read the license IDs from a txt file
with open('LisenceId.txt', 'r') as file:  # NOQA
    license_ids = [line.strip() for line in file.readlines()]


# Prepare the CSV file with headers
def create_csv_file(filename):
    """Create a new CSV file."""
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(
            ['License ID', 'TTB ID', 'Brand Name', 'Type', 'Item', 'Size', 'Per Bottle', 'Per Case', 'Bot/Case',
             'Alc.Cont', 'Discounts', 'Combo/Ltd.Avail', 'Age', 'Owner/Agent'])


if not os.path.exists(output_file):
    create_csv_file(output_file)


def read_file_data(filename):  # NOQA
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done = read_file_data(os.path.join(os.path.dirname(__file__), "already-done.txt"))


def save_to_already_done(license_id, page):
    with open("already-done.txt", "a") as file:
        file.write(f"{license_id},{page}\n")


def scrape_data(license_id):
    global total_pages
    url = "https://www.nyslapricepostings.com/rest/product/lookup"

    querystring = {"page": "1", "post_type": "LR", "license_id": license_id}
    payload = ""
    headers = {
        "accept": "application/json, text/plain, */*",
        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cookie": "visid_incap_2828582=1BD327o1TM60oeTNuGkpv//U7mcAAAAAQUIPAAAAAADrxM3y843+C2skOdgR/v5G; JSESSIONID=7F098836C0DAC2E53CD8D9DBF679DD9B; nlbi_2828582=QCMKKyd3iQueJrVbLj+BxgAAAAAn1/LcMWtbLNTkCLe/GW+n; incap_ses_218_2828582=QDycL55rZWQSvqczHn4GA3lc72cAAAAAdC2D1pW1AzRu0Smv4bHxcw==; reese84=3:mwgoBx1fyewpoH2hEwsSwA==:lwmShjpe/U49fGIlQkdWZ8AizR6O6fFxbFYLjZtX1UfND90kogC9BnzIuxThxnpma/Hm67tqC3apbkYQmYWG3sQesOqquAgaZEPIYa+uWcnC7gCvvJQYu4QcxPTS4z7a1K/YXkIpn5JOGKDH4G2z+4+us96z3dTp/gVGfIPCipYOV/x2KC4RmcDKmIxSzj12Nh4evJtXgQ4g2guyMCezl9zGJlNw8l3MFZJ1Y/zh2xFuA5JrmQsQaq30O2A0Xm2oqEbqp4pEj6a3AEg2gkFJFgh2/7cVscn65GgAge6XyuVSFXCI0klAbQFvtDNHVNS3gNd1ZwvxoneXMlrILmV5E0UXEesmL1eOltVH6bTbiWFJxARnVHnRht4cKJJH8YxFVY0U3aLivdLTjNSm7H+HKQ+EQ3+8fi4sM88Diaz37EZ0wnI5tjVRBCnGtu8SXmkraN043Z+LP3P5VBSacrwkCA==:x8RgmfCGypj406MLqTY7iLJnCE69OnKBC2DhWPqf3bQ=; nlbi_2828582_2147483392=4K2KWECu+W9XKL4PLj+BxgAAAADleWLGQERP0qAFLisP6qBX",
        "priority": "u=1, i",
        "referer": "https://www.nyslapricepostings.com/public/price-lookup?post_type=LR&license_id=878108&page=1",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
    }

    # Check the last processed page for the current license_id
    processed_pages = [entry.split(',')[1] for entry in already_done if entry.startswith(f"{license_id},")]
    next_page_to_scrape = 1  # Default to start from the first page

    if processed_pages:
        next_page_to_scrape = max(
            int(page) for page in processed_pages) + 1  # Start from the next page after the last processed one

    page = next_page_to_scrape
    while True:
        querystring["page"] = str(page)
        response = requests.get(url, data=payload, headers=headers, params=querystring)

        # Skip this license_id/page if already done
        if f"{license_id},{page}" in already_done:
            print(f"Skipping License ID: {license_id} on page {page}")
            break

        if response.status_code != 200:
            print(f"Failed to fetch data for License ID: {license_id} on page {page}")
            break

        print(f"Fetching data for License ID: {license_id} on page {page}")

        json_data = response.json()
        total_pages = json_data['pageInfo']['pagesCount']

        # If no data is returned, break the loop
        if 'data' not in json_data or not json_data['data']:
            break

        # Loop through the data items
        for item in json_data['data']:
            ttb_id = item.get('ttb_id', 'NA')
            brand_name = item.get('brand_name', 'NA')
            type_ = item.get('beverage_type', {}).get('description', 'NA')
            item_name = item.get('prod_name', 'NA')
            size = item.get('item_size', 'NA')
            per_bottle_price = item.get('bot_price', 'NA')
            per_case_price = item.get('case_price', 'NA')
            bot_case = item.get('botpercase', 'NA')
            alc_cont = item.get('alcohol', 'NA')

            if "B" in alc_cont:
                alc_cont = alc_cont.replace("B", "B (7% to 14%)")
            elif "C" in alc_cont:
                alc_cont = alc_cont.replace("C", "C Over (7% to 14%)")
            elif "A" in alc_cont:
                alc_cont = alc_cont.replace("A", "A lower than 7%")

            # Handling discounts if available
            discount_values = item.get('discount_values', [])
            discount = ", ".join(f"{d['type']} {d['amount']} on {d['quantity']} case" for d in
                                 discount_values) if discount_values else "NA"

            # Combo or Availability
            combo = item.get('availability', 'NA')
            if combo == "":
                combo = "NA"

            # Age and Owner/Agent information
            age = item.get('vintage', 'NA')
            agent_name = item.get('label_type', 'NA')
            if "A" in agent_name:
                agent_name = "Agent"
            elif agent_name == "O":
                agent_name = "Owner"
            elif agent_name == "":
                agent_name = "NA"

            # Prepare the row to be written in CSV
            row = [
                license_id, ttb_id, brand_name, type_, item_name, size,
                per_bottle_price, per_case_price, bot_case, alc_cont, discount, combo, age, agent_name
            ]

            # if any row element is empty, replace it with "NA"
            row = [elem if elem else "N/A" for elem in row]

            # Write the row to the CSV file
            with open(output_file, mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(row)

        save_to_already_done(license_id, page)

        # Break the loop if we have scraped all the pages for this license ID
        if page >= total_pages:
            break
        page += 1


# Scrape data for each license ID
for license_id in license_ids:
    scrape_data(license_id)

print("Data scraping complete!")
