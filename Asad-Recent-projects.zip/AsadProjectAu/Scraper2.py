import requests
import pandas as pd
import os

df = pd.read_csv('./LinksFile/Agent_Ids.csv')
agent_id = df['Agent ID'].tolist()[4500:9000]
states = df['State'].tolist()


def read_file_data(filename):
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done_urls = read_file_data("already-done.txt")

if not os.path.exists("Output_3.csv"):
    pd.DataFrame(columns=["Company", "Title", "Agent Name", "Address", "Phone", "Email"]).to_csv("Output_3.csv",
                                                                                                 index=False)

for ids, state in zip(agent_id, states):
    url = f"https://api.ratemyagent.com.au/v1/Profiles/Sales/Individual/{ids}/Details"

    if url in already_done_urls:
        print(f"Skipping Already scraped: {url}")
        continue

    payload = ""
    headers = {
        # "cookie": "AWSALB=Oj%2FBojF%2B%2BI9m49oBo5oXy3c2QYVbjXe7R2EQsBto4%2FZpGGVteEJVYIYq08TpchJw%2FE6VITwWERj1DbIYEkQikEnKHDSH6NlZJLAq8OcxAyFogLELB2kI0NK8MxRY; AWSALBCORS=Oj%2FBojF%2B%2BI9m49oBo5oXy3c2QYVbjXe7R2EQsBto4%2FZpGGVteEJVYIYq08TpchJw%2FE6VITwWERj1DbIYEkQikEnKHDSH6NlZJLAq8OcxAyFogLELB2kI0NK8MxRY; datadome=rbq9Mtl7hsMZNp96D35qFighIb4sIBj16Kt7LM3PDAn64rty~HdrFn2_NcQJb4HLQvkRqTWQQfBFBLjtXBcYMpSwu5QvEhIjSmZG_xLfSRGUlxEK_oOxjjUIDSTst_mL",
        "accept": "application/json, text/plain, */*",
        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
        "origin": "https://www.ratemyagent.com.au",
        "priority": "u=1, i",
        "referer": "https://www.ratemyagent.com.au/",
        "rma.json": "true",
        "rma.tempjson": "true",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        # "Cookie": "DeviceId=fe6710ff-0269-43ff-9310-425ccf5ca17b; SessionId=82bd6cc7-9d00-4e9c-bd30-84146a89024b; _hp2_id.825143451=%7B%22userId%22%3A%22235400329914739%22%2C%22pageviewId%22%3A%221391696785296471%22%2C%22sessionId%22%3A%222017566134916121%22%2C%22identity%22%3Anull%2C%22trackerVersion%22%3A%224.0%22%7D; datadome=x1LIQkfYu11IEFYjXI3UfgJIXoghNkDZeFg~s61NbOefIxbMrD9k6z9JTplEX6GALcHqcR35o3tRLszBK5tONL~5VtE9qfChOFi9fzmno7WdQMTtrGzewAkeXCicN4j7; AWSALB=c5IWbtmN4SCSViu7RPlkxAf2+V6hTUEu/Om3LBxgFLliD42ZXlF5OtfFcolylMx9oR20lfkG0SiPjarB0V+IkXGvEpMTCl/n/8e6l5k+MyYt3xTXxqn5bAJa5Bl7; AWSALBCORS=c5IWbtmN4SCSViu7RPlkxAf2+V6hTUEu/Om3LBxgFLliD42ZXlF5OtfFcolylMx9oR20lfkG0SiPjarB0V+IkXGvEpMTCl/n/8e6l5k+MyYt3xTXxqn5bAJa5Bl7"
    }

    response = requests.request("GET", url, data=payload, headers=headers)

    if response.status_code != 200:
        print(f"Failed to fetch data. Status code: {response.status_code}")
        break

    json_data = response.json()

    try:
        company_name = json_data.get('grouping', [{}])[0].get('name', 'NA')
    except:
        company_name = 'NA'

    title = json_data.get('title', 'NA')
    agent_name = json_data.get('fullName', 'NA')
    address = state
    phone = json_data.get('contact', {}).get('phone', 'NA')
    email_address = json_data.get('contact', {}).get('emailAddress', 'NA')

    print(
        f"Urls: {url} | Company: {company_name} | Address: {address} | Phone: {phone} | Agent: {agent_name} | Title: {title} | Email: {email_address}")

    new_data = pd.DataFrame([[company_name, title, agent_name, address, phone, email_address]],
                            columns=["Company", "Title", "Agent Name", "Address", "Phone", "Email"])
    new_data.to_csv("Output_3.csv", mode='a', header=False, index=False)

    with open("already-done.txt", 'a', encoding='utf-8') as file:
        file.write(f"{url}\n")
