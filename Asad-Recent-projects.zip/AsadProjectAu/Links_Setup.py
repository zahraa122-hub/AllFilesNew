
# read txt file urls
with open('./LinksFile/TasmaniaUrls.txt', 'r') as file:
    urls = file.readlines()


for url in urls:
    # remove newline characters
    url = url.strip()

    # split from last "-" and get ch032
    state = "Tasmania"
    agent_id = url.split('-')[-1].split('/')[0]
    print(f"Agent ID: {agent_id}")

    # Save ID and state into csv file using header "State" and "Agent ID"
    with open('./LinksFile/Agent_Ids.csv', 'a') as csv_file:
        if csv_file.tell() == 0:
            csv_file.write("State,Agent ID\n")
        csv_file.write(f"{state},{agent_id}\n")


