import grequests

url = "https://v2-api.wellcertified.com/api/project-directory/get"

querystring = {"page": "2"}

payload = ""
headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "access-control-allow-origin": "*",
    "origin": "https://account.wellcertified.com",
    "priority": "u=1, i",
    "referer": "https://account.wellcertified.com/",
    "sec-ch-ua-mobile": "?0",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
}

# send 50 requests at once

rs = (grequests.get(url, headers=headers, params=querystring) for _ in range(200))
responses = grequests.map(rs)
for response in responses:
    print(f"Status code: {response.status_code}")
