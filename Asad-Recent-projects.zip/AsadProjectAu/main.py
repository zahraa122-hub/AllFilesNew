import requests

url = "https://api.ratemyagent.com.au/ProfileLocation/Locality/6980/Sales/Individual"

payload = ""
headers = {
    # "cookie": "AWSALB=2vH96HHR0TzYEENK76fe5hWCkNtsafZqvTeWbUvi0i3oj%2FjDGQgk3EG6QT3toCE945I192pdMkp8ydauNajqjf7rbvzM4pUM6NJaxDXY5RaR%2FIO4NLyWZEtWoeui; AWSALBCORS=2vH96HHR0TzYEENK76fe5hWCkNtsafZqvTeWbUvi0i3oj%2FjDGQgk3EG6QT3toCE945I192pdMkp8ydauNajqjf7rbvzM4pUM6NJaxDXY5RaR%2FIO4NLyWZEtWoeui",
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "origin": "https://www.ratemyagent.com.au",
    "priority": "u=1, i",
    "referer": "https://www.ratemyagent.com.au/",
    "rma.json": "true",
    "rma.tempjson": "true",
    "sec-ch-ua-mobile": "?0",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    # "Cookie": "DeviceId=fe6710ff-0269-43ff-9310-425ccf5ca17b; SessionId=82bd6cc7-9d00-4e9c-bd30-84146a89024b; _hp2_ses_props.825143451=%7B%22ts%22%3A1742232597689%2C%22d%22%3A%22www.ratemyagent.com.au%22%2C%22h%22%3A%22%2F%22%7D; datadome=xhHnWrW5H7NRmGiTf5wm946_CV7i34XrGccAhKsly3Ry5bNWdkLrwL~GMQUDniJYn7TBL__kq7UDI_koIdexQz87GsCNTQ_i58OXOMmoAHEIf_SAuVpwQ9f4nDWJEdmd; AWSALB=bWN8VjZ3Q7thUUEqVZP1KzHUuuGv+iakR/AtMSiBF36tlsvgjKilZbw/kpnEY5I3vgIK6gSmYpRmGEIR3XR2zp+udZWGHlDCOEGTU8x8HJ+SCgW6GmWqI2pJprZG; AWSALBCORS=bWN8VjZ3Q7thUUEqVZP1KzHUuuGv+iakR/AtMSiBF36tlsvgjKilZbw/kpnEY5I3vgIK6gSmYpRmGEIR3XR2zp+udZWGHlDCOEGTU8x8HJ+SCgW6GmWqI2pJprZG; _hp2_id.825143451=%7B%22userId%22%3A%22235400329914739%22%2C%22pageviewId%22%3A%221391696785296471%22%2C%22sessionId%22%3A%222017566134916121%22%2C%22identity%22%3Anull%2C%22trackerVersion%22%3A%224.0%22%7D"
}

skip = 1
take = 9  # Number of results per request
output_file = "test.txt"
page_number = 1  # Start page number


def read_file_data(filename):
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done_urls = read_file_data("already-done.txt")

# Open the file in append mode
with open(output_file, "a") as file:
    while True:

        querystring = {
            "filter[locationAgentFilter][includeAll]": "true",
            "filter[locationAgentFilter][take]": str(take),
            "filter[locationAgentFilter][skip]": str(skip),
            "filter[locationAgentFilter][statisticType]": "TotalRecommendations"
        }

        response = requests.get(url, headers=headers, params=querystring)

        if response.status_code != 200:
            print(f"Error: {response.status_code}")
            break

        json_data = response.json()

        if 'results' not in json_data or not json_data['results']:
            print("No more data available.")
            break

        # Extract and save profile URLs
        for item in json_data['results']:
            if 'profileCode' in item:
                ids = item['profileCode']
                profile_url = f"https://api.ratemyagent.com.au/v1/Profiles/Sales/Individual/{ids}/Details"

                if profile_url in already_done_urls:
                    print(f"Skipping {profile_url}, already processed.")
                    continue

                print(f"Profile Urls: {profile_url}")

                with open(output_file, "a") as file:
                    file.write(f"{profile_url}\n")

        print(f"Fetched {len(json_data['results'])} profiles from Page {page_number}\n")

        skip += 9  # Increment skip by 9 for pagination
        page_number += 1  # Increment page number

print(f"\nAll profile URLs saved to {output_file}")
