import requests
import os
import csv
import time
from geopy.geocoders import Nominatim
import pandas as pd


def read_file_data(filename):
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


def create_csv_file(filename):
    """Create a new CSV file."""
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(
            ['Business Name', 'Street', 'Street 2', 'City', 'State', 'Phone', 'Zip Code', 'Latitude', 'Longitude',
             'Operation Hours'])


def get_lat_lon(location_name):
    """Retrieve latitude and longitude for a given location."""
    geolocator = Nominatim(user_agent="geo_locator")
    try:
        location = geolocator.geocode(location_name, timeout=10)
        if location:
            return location.latitude, location.longitude
    except Exception as e:
        print(f"Error fetching {location_name}: {e}")
    return None, None


def get_zipcode_from_coords(latitude_, longitude_):
    """Retrieve ZIP code from coordinates using Nominatim."""
    geolocator = Nominatim(user_agent="zipcode_finder")
    details = geolocator.reverse((latitude_, longitude_), language='en', timeout=10)
    if details and 'postcode' in details.raw['address']:
        zipcode = details.raw['address']['postcode']
        time.sleep(3)
        return zipcode
    else:
        print(f"No ZIP code found for ({latitude_}, {longitude_})")
        return "NA"


def remove_duplicates_using_pandas(filename):
    """Remove duplicates from a CSV file using pandas."""
    df = pd.read_csv(filename)

    # drop duplicates based on Phone
    df.drop_duplicates(subset=['Street', 'Phone'], inplace=True)

    print(f"==> Total new records: {len(df)}")
    df.to_csv(filename, index=False)


def scrape_location_data(location_name):
    """Get latitude and longitude for a location and scrape business data."""
    latitude, longitude = get_lat_lon(location_name)
    if not latitude or not longitude:
        print(f"Skipping {location_name} due to missing coordinates.")
        return

    payload = {
        "countryTo": "US",
        "findLocationType": "RMT",
        "lat": "",
        "latitude": latitude,
        "long": "",
        "longitude": longitude,
        "PayAgentId": None,
        "RequestCountry": "US",
        "RequiredPayoutAgents": True,
        "RequiredReceivingAgents": True,
        "RequiredCollectorAgents": True,
        "RequiredReceivingAndPayoutAgents": False,
        "ATMFilterType": 0
    }

    headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Content-Type": "application/json",
        "CultureCode": "en-US",
        "IsoCode": "US",
        "Origin": "https://www.riamoneytransfer.com",
        "Referer": "https://www.riamoneytransfer.com/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    }

    print(f"Processing Location: {location_name} | Latitude: {latitude} - Longitude: {longitude}")
    url = "https://public.riamoneytransfer.com/location/agent-locations"
    response = requests.request("PUT", url, json=payload, headers=headers)
    json_data = response.json()

    already_done = read_file_data(os.path.join(os.path.dirname(__file__), "already-done.txt"))

    for location in json_data:
        business_name = location.get("name", "NA")
        street = location.get("address", "NA")
        street2 = location.get("address2", "NA")
        city = location.get("city", "NA")
        state = location.get("state", "NA")
        phone = location.get("phone", "NA")
        operation_hours = "\n".join([" - ".join(map(str, day.values())) for day in location.get("businessHours", [])])
        if not operation_hours:
            operation_hours = "NA"

        zip_code = get_zipcode_from_coords(latitude, longitude)

        if f"{business_name}-{phone}" in already_done:
            print(f"Skipping Business: {business_name} - Phone: {phone}")
            continue

        record = [business_name, street, street2, city, state, phone, zip_code, latitude, longitude, operation_hours]

        with open(os.path.join(os.path.dirname(__file__), "Ria-Money-Data.csv"), 'a', encoding='utf-8',
                  newline='') as file:
            writer = csv.writer(file)
            writer.writerow(record)

        with open(os.path.join(os.path.dirname(__file__), "already-done.txt"), 'a', encoding='utf-8') as file:
            file.write(f"{business_name}-{phone}\n")

        remove_duplicates_using_pandas(os.path.join(os.path.dirname(__file__), "Ria-Money-Data.csv"))

        time.sleep(2)  # Sleep to avoid rate limits


def process_all_locations(input_file):  # NOQA
    """Process all locations from a file."""
    locations = read_file_data(input_file)
    for location in locations:
        scrape_location_data(location)
        time.sleep(3)  # Sleep between requests


# Main execution
input_file = os.path.join(os.path.dirname(__file__), "Locations.txt")
if not os.path.exists(os.path.join(os.path.dirname(__file__), "Ria-Money-Data.csv")):
    create_csv_file(os.path.join(os.path.dirname(__file__), "Ria-Money-Data.csv"))

process_all_locations(input_file)
