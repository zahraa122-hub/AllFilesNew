import csv
from playwright.sync_api import sync_playwright
import json
import time
import os
import pandas as pd


def create_csv_file(filename):
    """Create a new CSV file."""
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['Business Name', 'Street', 'Street 2', 'City', 'State', 'ZIP Code', 'Phone',
                         'Latitude', 'Longitude', 'Operation Hours'])


if not os.path.exists(os.path.join(os.path.dirname(__file__), "Western-Data-2.csv")):
    create_csv_file(os.path.join(os.path.dirname(__file__), "Western-Data-2.csv"))


def read_file_data(filename):
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done = read_file_data(os.path.join(os.path.dirname(__file__), "already-done.txt"))
locations = read_file_data(os.path.join(os.path.dirname(__file__), "Locations.txt"))


def remove_duplicates_using_pandas(filename):
    """Remove duplicates from a CSV file using pandas."""
    df = pd.read_csv(filename)
    df.drop_duplicates(subset=['Phone', 'Street'], inplace=True)
    df.to_csv(filename, index=False)


def append_to_file(filename, data):
    """Append data to a file."""
    with open(filename, 'a', encoding='utf-8') as file:
        file.write(f"{data}\n")


def extract_data(file_path="response.json"):
    with open(file_path, "r") as file:
        data = json.load(file)

    locations = data.get("data", {}).get("locations", {}).get("results", [])
    for location in locations:
        operation_hours = location.get("desktopHours", {}).get("desktopHours", {})
        operation_hours_str = "\n".join([f"{day}: {hours}" for day, hours in operation_hours.items()])
        location_id = location.get("id")
        phone = location.get("s_phone")

        # Create a unique identifier to track processed data
        unique_key = f"{location_id} - {phone}"
        if unique_key in already_done:
            continue  # Skip already processed entries

        record = [
            location.get("name"),
            location.get("streetAddress"),
            location.get("streetAddress2"),
            location.get("city"),
            location.get("state"),
            location.get("postal"),
            location.get("s_phone"),
            location.get("latitude"),
            location.get("longitude"),
            operation_hours_str
        ]

        print(record)

        with open(os.path.join(os.path.dirname(__file__), "Western-Data-2.csv"), 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(record)

        append_to_file(os.path.join(os.path.dirname(__file__), "already-done.txt"), unique_key)
        remove_duplicates_using_pandas(os.path.join(os.path.dirname(__file__), "Western-Data-2.csv"))


def scrape_locations():
    with sync_playwright() as p:
        browser = p.firefox.launch(headless=False)
        page = browser.new_page()

        def handle_response(response):
            if response.url.startswith("https://www.westernunion.com/router/"):
                try:
                    json_data = response.json()
                    with open("response.json", 'w') as f:
                        json.dump(json_data, f, indent=2)
                    extract_data("response.json")
                except Exception as e:
                    print("Error parsing JSON:", e)

        page.on("response", handle_response)
        page.goto("https://www.westernunion.com/global-services/find-locations", wait_until="networkidle", timeout=0)

        for location in locations:
            if location not in already_done:
                print(f"Scraping: {location}")

                # Search for location
                page.fill('//input', location)
                page.click('//div[@id="icon_search"]//button')
                time.sleep(5)  # Wait for response

                # Scrape all pages
                try:
                    total_pages = page.query_selector_all('//ul[@aria-label="Pagination"]//li//a')
                    total_page_no = int(total_pages[-2].inner_text().replace('\nPage Number of Results',
                                                                             '').strip()) if total_pages else 1
                except Exception as e:
                    print(f"Error finding total pages: {e}")
                    total_page_no = 1

                print(f"Total pages for {location}: {total_page_no}")

                for _ in range(total_page_no - 1):
                    time.sleep(2)
                    try:
                        next_page = page.query_selector('//a[@id="right_arrow"]')
                        if next_page:
                            next_page.click()
                            time.sleep(3)
                    except Exception as e:
                        print("Error clicking next page:", e)

                print(f"Done: {location}")

        browser.close()


scrape_locations()
