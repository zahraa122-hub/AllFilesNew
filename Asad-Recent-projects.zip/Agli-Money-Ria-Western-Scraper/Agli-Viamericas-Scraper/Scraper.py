import requests
import os
import csv
from geopy.geocoders import Nominatim
import time
import pandas as pd


# Existing geolocation function
def get_lat_lon(location_name):
    geolocator = Nominatim(user_agent="geo_locator")
    try:
        location = geolocator.geocode(location_name, timeout=10)
        if location:
            return location.latitude, location.longitude
    except Exception as e:
        print(f"Error fetching {location_name}: {e}")
    return None, None


# Existing file reading function
def read_file_data(filename):
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done = read_file_data(os.path.join(os.path.dirname(__file__), 'already-done.txt'))


# Existing CSV creation function
def create_csv_file(filename):
    """Create a new CSV file."""
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(
            ['Business Name', 'Latitude', 'Longitude', 'Street', 'City', 'State', 'Zip Code'])


def remove_duplicates_using_pandas(filename):
    """Remove duplicates from a CSV file using pandas."""
    df = pd.read_csv(filename, encoding='utf-8')
    df.drop_duplicates(subset=['Business Name', 'Street'], inplace=True)

    print(f"==> Total new records: {len(df)}")
    df.to_csv(filename, index=False)


# New function to scrape data for a given latitude and longitude
def scrape_location_data(lat, lon, output_file):
    url = "https://viatabservices.viamericas.net/v1/agcy-locations"

    querystring = {
        "lat": str(lat),
        "lon": str(lon),
        "dist": "20",
        "callerData": f"98.159.37.243,{lat},{lon},US,{lat},{lon}"
    }

    headers = {
        "accept": "application/json, text/plain, */*",
        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
        "origin": "https://agtl.viamericas.net",
        "priority": "u=1, i",
        "referer": "https://agtl.viamericas.net/",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
    }

    response = requests.get(url, headers=headers, params=querystring)
    data = response.json()

    # Splitting the data
    locations = data.split("|")

    with open(output_file, mode='a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        for location in locations[1:]:
            business_name = location.split("^")[0]
            latitude = location.split("^")[1]
            longitude = location.split("^")[2]
            street = location.split("^")[4].split("<BR>")[0]
            city = location.split("^")[4].split("<BR>")[1].split(",")[0]
            state = location.split("^")[4].split(",")[1].split(" ")[1]
            zip_code = location.split("^")[4].split(",")[1].split(" ")[2]

            business_name = business_name.strip() if business_name else "NA"
            latitude = latitude.strip() if latitude else "NA"
            longitude = longitude.strip() if longitude else "NA"
            street = street.strip() if street else "NA"
            city = city.strip() if city else "NA"
            state = state.strip() if state else "NA"
            zip_code = zip_code.strip() if zip_code else "NA"

            if business_name and street in already_done:
                print(f"Skipping {business_name} - {street}, {city}, {state}, {zip_code}")
                continue

            record = [business_name, latitude, longitude, street, city, state, zip_code]
            writer.writerow(record)

            with open(os.path.join(os.path.dirname(__file__), 'already-done.txt'), 'a') as f:
                f.write(f"{business_name}, {street}\n")


# Main code
location_input_file = 'Locations.txt'
output_file = 'Agli-Viamericas-Data-2.csv'

if not os.path.exists(output_file):
    create_csv_file(output_file)

locations = read_file_data(location_input_file)

for location in locations:
    print(f"Processing location: {location}")
    lat, lon = get_lat_lon(location)

    if lat and lon:
        print(f"Coordinates found - Lat: {lat}, Lon: {lon}")
        scrape_location_data(lat, lon, output_file)
        remove_duplicates_using_pandas(output_file)

    time.sleep(3)
