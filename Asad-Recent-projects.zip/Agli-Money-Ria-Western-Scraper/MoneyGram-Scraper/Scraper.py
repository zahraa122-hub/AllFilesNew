import requests
import os
import csv
import pandas as pd
import time


def read_txt_file(filename):
    """Read locations from a text file, one per line."""
    with open(filename, 'r', encoding='utf-8') as file:
        return [line.strip() for line in file.readlines() if line.strip()]


locations = read_txt_file(os.path.join(os.path.dirname(__file__), "Locations.txt"))


def read_file_data(filename):  # NOQA
    """Read data from a file."""
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip().split("\n")


already_done = read_file_data(os.path.join(os.path.dirname(__file__), "already-done.txt"))


def remove_duplicates_using_pandas(filename):
    """Remove duplicates from a CSV file using pandas."""
    df = pd.read_csv(filename)

    # drop duplicates based on Phone
    df.drop_duplicates(subset=['Street', 'Phone'], inplace=True)

    print(f"==> Total new records: {len(df)}")
    df.to_csv(filename, index=False)


def create_csv_file(filename):
    """Create a new CSV file.
    """
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(
            ['Business Name', 'Street', 'Street 2', 'City', 'State', 'Zip Code', 'Phone', 'Latitude', 'Longitude',
             'Operation Hours'])


if not os.path.exists(os.path.join(os.path.dirname(__file__), "Money-Gram-Data.csv")):
    create_csv_file(os.path.join(os.path.dirname(__file__), "Money-Gram-Data.csv"))

url = "https://consumerapi.moneygram.com/services/capi/api/v1/location"

for address in locations:

    querystring = {"address": address, "searchRadius": "250", "limit": "10000",
                   "country": "US", "radiusuom": "mile", "amazonCard": "false", "sendMoney": "false",
                   "receiveMoney": "false", "billPayment": "false", "reloadOtherCard": "false", "addToPhone": "false",
                   "payPal": "false", "moneyOrder": "false", "xpressPackage": "false", "purchaseMoneygramCard": "false",
                   "reloadMoneygramCard": "false", "receiveToCard": "false", "expressPayment": "false", "purpose": "",
                   "agent": ""}

    payload = ""
    headers = {
        "accept": "application/json",
        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
        "clientkey": "Basic V0VCX2VkYjI0ZDc5LTA0ODItNDdlMi1hNmQ2LTc4ZGY5YzI4MmM0ZTo1MTNlMTEyOS0yZTJmLTRlYmUtYjkwMi02YTVkMGViMDNjZjc=",
        "locale-header": "en_US",
        "origin": "https://www.moneygram.com",
        "priority": "u=1, i",
        "referer": "https://www.moneygram.com/",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Cookie": "visid_incap_2222183=VXRkiwOYRjenNH1KdxuOwrYs4GcAAAAAQUIPAAAAAAA7WDhnUtxFsrBM3PZwBaJW; notice_preferences=3:; notice_gdpr_prefs=0,1,2,3:; cmapi_gtm_bl=; cmapi_cookie_privacy=permit 1,2,3,4; visid_incap_2163526=wB3A3r6/SGqJOqq8jhDJaM8s4GcAAAAAQUIPAAAAAAA9oFGlvd9+VA3SUKRakcOg; _gcl_au=1.1.728671937.1743089491; _cs_c=0; afUserId=9686b28d-b658-4563-9738-665c0e378cd7-p; AF_SYNC=1743089494984; _ga=GA1.1.54162524.1743089528; nlbi_2222183=q5fHHWbezQlCA4EwUnWprgAAAABp1hdUTQSCOyPVVEGsxF7C; incap_ses_967_2222183=aBpiY1tr/lemFH9edXlrDSOi5WcAAAAAsj6dhp1Z2r8jqOeLV02PkA==; TAsessionID=55edcc7f-8bb5-47ce-8158-92ea7c104ee3|EXISTING; notice_behavior=implied,us; nlbi_2222183_2147483392=DI9dB08HQV09n4IgUnWprgAAAACehqfWO9wZmb/i/rVd/6aA; reese84=3:aRKAj5nrsnYQtHyhgxLsQA==:SimDtWEIx93mJ6oW/ucOMFF5uSSrH6fZWw+Msv2OV/vRkT4Nqh/yr80BW6Wkxf8j7WxSsWCD7itVXkYHt11LxCf/vu2aMR8PtVTQW4P6AYDArmCaGVcsDCYTfRnvmNbhaKFNZFE7Aj97euHRmX1UVM/lNOC7pt4/Kp91NSd19TZcgnH2IEi5QQVnK+hYepq8R874kSkkU6mHzuJFUsP9FHNGZU+iBnYLhdB9VPEVmhTEkjP1HV32u68cohKJ2sFN+JmTgoXSXJnI+SOhS8KxaTE8r0/Aqr6hVtg29G+nGhWx6dL0NWwxhYaZj18ZMzs0rnWxjWr38V71nTTyK3+AxPHfRbevrNDfe5LShfFJYcyGMMja+lItTSOxr49VpV7yxQyzEtGGx5qYfiOeTEqf/kVWYZe5gX0i8VBtHoRMUeF4GfYLViYxqvuGpdSkdIJz6mjtcxMYVK5H5jqG+IrRnA==:YJD6hPMCWqAREaXCJfuMinL7Uz69FLPSqJsLF2mUC3A=; _cs_id=c789ba43-287f-a39b-94c7-c1b4f8c7c0e7.1743089494.2.1743102501.1743102501.1.1777253494599.1.x; _cs_cvars=%7B%221%22%3A%5B%22country_code%22%2C%22undefined%22%5D%2C%222%22%3A%5B%22lang_code%22%2C%22en%22%5D%2C%223%22%3A%5B%22receiving_country%22%2C%22undefined%22%5D%2C%225%22%3A%5B%22client_type%22%2C%22unknown%22%5D%7D; usi_return_visitor=Fri%20Mar%2028%202025%2000%3A08%3A25%20GMT%2B0500%20(Pakistan%20Standard%20Time); nlbi_2163526=wpq+LKBIGjqGtkIVB1D/egAAAAAmZc5X/sbg29EmHTDm9hNl; incap_ses_967_2163526=nCaef7TOi2HLGn9edXlrDSui5WcAAAAAmSQZ7B0UuqFfgBzDkVr5/g==; _ga_419TZ53GJ4=GS1.1.1743102506.2.1.1743102506.0.0.0; IR_gbd=moneygram.com; IR_16828=1743102506898%7C0%7C1743102506898%7C%7C; _uetsid=a6d308c00b2011f0a3e6f3bfbc0bbcd8; _uetvid=a6d35e400b2011f080f0d76c01428b66; _cs_s=1.5.0.9.1743104331842"
    }

    print(f"Processed Locations: {address}")

    response = requests.request("GET", url, data=payload, headers=headers, params=querystring)
    json_data = response.json()

    # ID, Business name, street, street 2, city, state, zip, phone, latitude, longitude, and operation hours.
    for location in json_data.get('locations', []):
        details = location.get('locationDetails', {})
        phone_info = location.get('locationPhone', {})

        business_name = details.get('name', 'N/A')
        street = details.get('addressLine1', 'N/A')
        street2 = details.get('addressLine2', 'N/A')
        city = details.get('city', 'N/A')
        state = details.get('state', 'N/A')
        zip_code = details.get('postalCode', 'N/A')
        phone = phone_info.get('phone', 'N/A')
        latitude = details.get('latitude', 'N/A')
        longitude = details.get('longitude', 'N/A')
        operation_hours_dict = location.get('locationOperatingHours', {})
        operation_hours = "\n".join([f"{day}: {hours}" for day, hours in operation_hours_dict.items()])

        if street and phone in already_done:
            print(f"Already done: {street} - {phone}")
            continue

        record = [business_name, street, street2, city, state, zip_code, phone, latitude, longitude, operation_hours]

        with open(os.path.join(os.path.dirname(__file__), "Money-Gram-Data.csv"), 'a',
                  encoding='utf-8', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(record)

        with open(os.path.join(os.path.dirname(__file__), "already-done.txt"), 'a', encoding='utf-8') as file:
            file.write(f"{street} - {phone}\n")

    remove_duplicates_using_pandas(os.path.join(os.path.dirname(__file__), "Money-Gram-Data.csv"))

    time.sleep(5)
