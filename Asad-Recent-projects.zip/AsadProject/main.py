import requests
import csv
from datetime import datetime


def convert_date(iso_date):
    dt = datetime.fromisoformat(iso_date.replace("Z", "+00:00"))  # Convert to datetime object
    return dt.strftime("%b %d %Y")  # Format as 'Mar 12 2025'


url = "https://api.seedify.fund/api/v2/pools"
headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "origin": "https://seedify.fund",
    "priority": "u=1, i",
    "referer": "https://seedify.fund/",
    "sec-ch-ua-mobile": "?0",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
}

# CSV file setup
csv_filename = "Output.csv"
with open(csv_filename, mode="w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["Project Name", "Network", "Total Raised", "End Date", "Round Type", "Website"])

    # Loop through 40 pages
    for page in range(1, 41):
        querystring = {"poolType": "completed", "page": str(page)}
        response = requests.get(url, headers=headers, params=querystring)

        if response.status_code == 200:
            json_data = response.json()

            if "data" in json_data:
                for item in json_data["data"]:
                    project_name = item.get("title", "N/A")
                    network = item.get("project_network", "N/A")
                    total_raised = item.get("total_raised", "N/A")
                    end_date = item.get("createdAt", "N/A")
                    end_date = convert_date(end_date)
                    round_type = item.get("up_pool_access", "N/A")
                    website = item.get("browser_web_link", "N/A")

                    print(f"Project Name: {project_name}")

                    writer.writerow([project_name, network, total_raised, end_date, round_type, website])
        else:
            print(f"Failed to retrieve page {page}, status code: {response.status_code}")

print(f"Data scraping completed. Saved to {csv_filename}")
