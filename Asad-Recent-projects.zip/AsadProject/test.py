from datetime import datetime


def convert_date(iso_date):
    dt = datetime.fromisoformat(iso_date.replace("Z", "+00:00"))  # Convert to datetime object
    return dt.strftime("%b %d %Y")  # Format as 'Mar 12 2025'


# Example usage
date_string = "2025-03-04T12:05:40.319Z"
formatted_date = convert_date(date_string)
print(formatted_date)  # Output: Mar 12 2025
