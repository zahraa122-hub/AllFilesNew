import pandas as pd
import re
from fuzzywuzzy import process


def normalize_city_name(city):
    """Normalize city names by stripping extra details and converting to uppercase."""
    city = re.sub(r',.*', '', city).strip().upper()
    return city


def find_unmatched_locations(csv_file, txt_file):
    # Read CSV file
    df = pd.read_csv(csv_file)
    csv_cities = set(df['City'].dropna().apply(normalize_city_name))

    # Read TXT file
    with open(txt_file, 'r', encoding='utf-8') as file:
        txt_locations = [normalize_city_name(line.strip()) for line in file if line.strip()]

    # Find unmatched locations using fuzzy matching
    unmatched_locations = []
    for location in txt_locations:
        best_match, score = process.extractOne(location, csv_cities) if csv_cities else (None, 0)
        if score < 90:  # Adjust threshold as needed
            unmatched_locations.append(location)

    # Print unmatched locations
    if unmatched_locations:
        print("Locations not found in CSV:")
        for loc in unmatched_locations:
            print(loc)

            # Save this to a csv file with website name
            with open('unmatched_Locations/Agli-Viamericas-unmatched.csv', 'a') as f:
                f.write(loc + '\n')

    else:
        print("All locations matched with CSV cities.")


# Example usage
csv_file = "Agli-Viamericas-Data.csv"  # Replace with actual CSV file
txt_file = "Locations.txt"  # Replace with actual TXT file
find_unmatched_locations(csv_file, txt_file)